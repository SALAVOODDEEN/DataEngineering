# Databricks notebook source
# Fetch synapse JDBC connection string/url from Azure kay vaults by utlising Databricks secret scope
# Inputs: adb_secret_scope_name - Secret scope name 
# Inputs: adb_synapse_connection_string - Secret name for Synapse JDBC URL in Azure Key Vault

def create_databricks_to_synapse_connection(adb_secret_scope_name, adb_synapse_connection_string) :
    try:
        # Configure connection between Databricks to Synapse
        synapse_jdbc_url = dbutils.secrets.get(scope = adb_secret_scope_name, key = adb_synapse_connection_string)
        return synapse_jdbc_url
    except Exception as e:
        # Log the error along with the traceback
        filename = 'nb_query_on_synapse.dbc'
        logger(logger_level_error, f"An error occurred while configuring the connection between Databricks and Synapse.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
    
    return "success"

# COMMAND ----------

# Genralised function to query on synapse tables
# Inputs: synapse_jdbc_url - Synapse JDBC connection URL
# Inputs: synapse_schema_name, query_table_name - schema & table name on which the query will be run
# Inputs: column_list - Columns of the table that the query has to return

def get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, query_table_name, column_list):
    try:
        # Load the source system details
        query_result = spark.read.format("com.databricks.spark.sqldw") \
                                    .option("url", synapse_jdbc_url) \
                                    .option("dbtable", f"{synapse_schema_name}.{query_table_name}") \
                                    .load()\
                                    .select(*column_list)
        return query_result

    except Exception as e:
        # Log the error along with the traceback
        filename = 'nb_query_on_synapse.dbc'
        logger(logger_level_error, f"An error occurred while executing a query on Synapse in the nb_query_on_synapse notebook.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
