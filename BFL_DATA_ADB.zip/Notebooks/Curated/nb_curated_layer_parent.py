# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Curated Layer Generic Framework 
# MAGIC
# MAGIC
# MAGIC 1. The Curated Layer Framework is a generic framework designed to handle various data operations in a Databricks Delta Tables. It performs the following key tasks:
# MAGIC
# MAGIC 2. Reading Data from Raw ADLS Layer: The framework fetches data from the raw Azure Data Lake Storage (ADLS) layer. This data is typically unprocessed and in its raw format, making it a rich source for data analysis and transformation.
# MAGIC
# MAGIC 3. Data Quality Check: The framework performs Data Quality (DQ) checks to ensure the integrity and quality of the data. These checks can include validation rules, data type checks, null checks, and more. The DQ checks help in identifying any inconsistencies, errors, or anomalies in the data.
# MAGIC
# MAGIC 4. SCD Type 1 Handling: The framework handles Slowly Changing Dimension (SCD) Type 1 operations. In SCD Type 1, the old data is overwritten with new data. This is useful in scenarios where maintaining historical data is not necessary and the latest data is of the utmost importance.
# MAGIC
# MAGIC 5. SCD Type 2 Handling: The framework also handles SCD Type 2 operations. In SCD Type 2, a new record is added to the table to represent the new information, while the old record is retained to preserve the historical data. This is useful in scenarios where tracking changes over time is crucial.
# MAGIC
# MAGIC 6. The Curated Layer Framework ensures that data operations are handled efficiently and accurately, providing a reliable foundation for downstream data analysis and decision-making processes.
# MAGIC
# MAGIC
# MAGIC
# MAGIC                                             

# COMMAND ----------

# MAGIC %md
# MAGIC Below command is useful when you want to reuse code from another notebook without copying and pasting the entire code into the current notebook. It allows you to modularize your code and separate different functionalities into separate notebooks.

# COMMAND ----------

# MAGIC %md
# MAGIC By using below command we can use libraries provide essential functionality for various data analysis, transformations, time-related operations, and working with Delta tables in Databricks.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %md
# MAGIC By using below command we are defining these constants, we can easily refer constants value using the appropriate constant name.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %md
# MAGIC Below function is main function which handled entire data quality framework by executing data quality functions, creating summary report for each table.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_dq_parent"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_dq_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC By Using below command we are executing logger function takes two parameters: level and message. It retrieves the current frame object, gets the current time in the 'Asia/Kolkata' timezone, and assigns a filename. Then, it prints the log message in a specific format, including the current time, log level, filename, and the provided message.
# MAGIC
# MAGIC This function can be used to log messages at different levels (e.g., DEBUG, INFO, WARN, ERROR, Common Inputs from ADLS) with the corresponding log level, timestamp, filename, and message.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %md
# MAGIC By Using below command we are defines a Python function called append_log that retunrs execution logs of curated layer to pass it to ADF as a dictionary to update logs activity. It loads data from a source system, calculates the duration of the task, adds various metadata columns, and then appends the log entry to a table in a Synapse SQL Data Warehouse.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_exe_logs_dict"

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command can are executing SCD Type 1  & SCD Type 2 which are the techniques used to handle changes in dimension data over time in a data warehouse or data integration process.
# MAGIC
# MAGIC In SCD Type 1, when there is a change in a dimension attribute value, the existing record is updated directly without preserving historical data. This means that only the most recent value is stored, and the previous values are overwritten.
# MAGIC
# MAGIC In SCD Type 2, when there is a change in a dimension attribute value, a new record is added to the dimension table to represent the new attribute value, while the existing record is retained with its original attribute value. This means that both the historical and current values are preserved in the dimension table.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_scd_implementation"

# COMMAND ----------

# MAGIC %md
# MAGIC By using below command it is a function can return required fileds from synapse to databricks.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_query_on_synapse"

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command are creating dictionary of curated layer logs to pass it to ADF.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command we are fetching the required parameter from ADF.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_get_params_from_adf"

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command we are checking the file extension of source adls files.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_check_extension"

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command we are adding meta data columns to source data frame.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_add_meta_data_columns"

# COMMAND ----------

# Declaring the notebook name
filename = 'nb_curated_layer_parent.dbc'

# COMMAND ----------

################################################## Main Funtion ##################################################

# COMMAND ----------

# MAGIC %md
# MAGIC  # ********************************************** Curated Layer Function ****************************************************
# MAGIC
# MAGIC
# MAGIC 1. The function loads the source system details from a specified table in the Synapse schema. It fetches details like the destination path, object name, load type, Data Quality (DQ) active status, and Slowly Changing Dimension (SCD) type.
# MAGIC 2. Based on these details, the function constructs the source table path and checks if it exists. If the source table path exists, it loads the source data. If not, it exits with an error message.
# MAGIC 3. The function then checks if the DataFrame is empty. If it is, it exits with an error message. If not, it proceeds to handle different SCD types.
# MAGIC 4. If the SCD type is SCD-1, it calls the `handle_scd_type_1` function to handle SCD Type 1 operations. If the SCD type is SCD-2, it calls the `handle_scd_type_2` function to handle SCD Type 2 operations.
# MAGIC 5. This function ensures that data operations are handled efficiently and accurately based on the specified configurations. It is a crucial part of the data management process in a data lakehouse.
# MAGIC

# COMMAND ----------

# Calling function to fetch all input parameters from ADF
try:
    created_by, updated_by, object_source, object_name, src_object_id, dest_save_type, load_type, column_to_exclude_frm_scd, business_key, load_to_date, load_from_date, source_path, pipeline_name, pipeline_run_id, pipeline_trigger_name, is_dq_active, adb_curated_source_url, adb_curated_dest_url, adb_dq_dest_url, adb_curated_catlog_schema, adb_datasharing_catlog_schema, adb_synapse_connection_string = get_curated_parameters_from_adf()
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_get_params_from_adf notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_get_params_from_adf notebook:", str(e))

# Fetch scope name from source url
adls_storage_account_name = adb_curated_source_url.split('@')[1].split('.')[0]

try:
    # For creating connection between databricks to synapse
    synapse_jdbc_url = create_databricks_to_synapse_connection(adb_secret_scope_name, adb_synapse_connection_string)
    if synapse_jdbc_url is not None :
        # Configure connection between Databricks to Synapse
        logger(logger_level_info, f"The configuration of the connection between Databricks and Synapse has been successfully completed.", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_synapse_connectivity notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_synapse_connectivity notebook:", str(e))

try:  
    # To get query result from synapse 
    query_log_result_df = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, log_table_name, log_column_list)

    # Filtering the data frame of synapse query result based on the condition
    query_log_result_df = query_log_result_df.filter(
        (col("src_object_id") == src_object_id) & 
        (date_format(col("load_from_date"), "yyyy-MM-dd") == date_format(lit(load_from_date), "yyyy-MM-dd")))

    # Checking is data frame is empty or not
    if query_log_result_df.isEmpty():
        # Call the logger function with a log level and message
        logger(logger_level_error, f"The {log_table_name} DataFrame is empty, indicating an issue between Databricks and Synapse.",execution_log_list, filename)
        raise Exception(f"The {log_table_name} DataFrame is empty, indicating an issue between Databricks and Synapse.")
    
    logger(logger_level_info, f"The loading of the source system details has been successfully executed.", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_query_on_synapse notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_query_on_synapse notebook:", str(e))


try:
    # Fetching exec_log_id from synapse
    exec_log_id = query_log_result_df.select(col("exec_log_id")).first()[0]

    # Checking is exec_log_id has value or not 
    if exec_log_id:
        logger(logger_level_info, f"The retrieval of exec_log_id from Synapse has been successfully completed for {object_name}.", execution_log_list, filename)
except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while fetching exec_log_id from Synapse {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while fetching exec_log_id from Synapse.", str(e))

try:  
    # To get query result from synapse 
    query_pl_src_log_result_df = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, config_table_name, config_column_list)

    # Filtering the data frame of synapse query result based on below condition
    query_pl_src_log_result_df = query_pl_src_log_result_df.filter((col("src_object_id") == src_object_id))

    # Checking is data frame is empty or not
    if query_pl_src_log_result_df.isEmpty():
        # Call the logger function with a log level and message
        logger(logger_level_error, f"The {config_table_name} DataFrame is empty; there will be an issue between Databricks and Synapse.",execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"The {config_table_name} DataFrame is empty; there will be an issue between Databricks and Synapse.")
    
    logger(logger_level_info, f"The loading of the source system details has been successfully executed.", execution_log_list, filename)
except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while executing the get_query_result_from_synapse function {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while executing the get_query_result_from_synapse function.", str(e))

try:
    # Fetching desti_path from synapse
    desti_path = query_pl_src_log_result_df.select(col("desti_path")).first()[0]

    logger(logger_level_info, f"The fetching of desti_path from Synapse has been successfully executed: {object_name}.", execution_log_list, filename)

    # Define the pattern to match
    pattern = re.compile(r'BFIL/PRAGATI_(S1|S2|S3|S4|S5|S6|S7)/')

    # Replace the pattern with the desired string
    desti_path = pattern.sub('BFIL/PRAGATI/', desti_path)

    logger(logger_level_info, f"Fetching desti_path from Synapse is from PRAGATI_S* changed it to PRAGATI for table: {object_name}.", execution_log_list, filename)

except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while fetching desti_path from Synapse {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while fetching desti_path from Synapse.", str(e))

# Check either desti_path has _h or _H at the end of string
if desti_path.endswith("_h") or desti_path.endswith("_H"):
    try:  
        # Remove "_h" or "_H" from the end of the string
        desti_path = desti_path[:-2]
        logger(logger_level_info, f"_h or _H has been removed from {desti_path} for historical pipeline execution.", execution_log_list, filename)
    except Exception as e:
        # Log the error along with the traceback
        logger(logger_level_error, f"An error occurred while '_h' was being removed from {desti_path} for historical pipeline execution {str(e)}.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An error occurred while '_h' was being removed from {desti_path} for historical pipeline execution.", str(e))

# Convert column_to_exclude_frm_scd to a list
column_to_exclude_frm_scd = column_to_exclude_frm_scd.split(",")

# Construct the source table path
source_table_path = adb_curated_source_url + "/" + source_path 
try:
    extension_of_file = check_file_extension(source_table_path)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_check_extension notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_check_extension notebook:", str(e))

# Check if source table path exists
try :
    if source_path is not None and source_path != '':
        # Load the source data
        try:
            # Check file extension is parquet
            if extension_of_file == ".parquet" :
                # Reading source data using spark.read
                source_data_df = spark.read.parquet(source_table_path)
                source_row_count = source_data_df.count()
                logger(logger_level_info, f"The DataFrame count after reading source data for the table: {object_name} is {source_row_count}", execution_log_list, filename)

                # Check if DataFrame is empty
                if source_data_df.isEmpty() or source_row_count == 0 :
                    # Call the logger function with a log level and message
                    logger(logger_level_info, f"The DataFrame is empty and count is {source_row_count} for curated layer implementation for the table: {object_name}.", execution_log_list, filename)

                    try:
                        update_logs(src_object_id, source_data_df, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                    except Exception as e:
                        logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                        print(*execution_log_list,sep='\n')
                        # Handle the exception or display the error message as needed
                        raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))

                logger(logger_level_info, f"The source DataFrame has been successfully created for table : {object_name}.", execution_log_list, filename)
                try:
                    # Function call to add meta data into source data frame
                    source_data_df = add_meta_data_into_source_df(source_data_df, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, object_name, load_to_date, load_type, desti_path)
                    logger(logger_level_info, f"Adding additional metadata columns and default values to the source dataframe has been successfully executed.", execution_log_list, filename)
                except Exception as e:
                    logger(logger_level_error, f"An error occurred in the nb_add_meta_data_columns notebook: {str(e)}", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    # Handle the exception or display the error message as needed
                    raise Exception("An error occurred in the nb_add_meta_data_columns notebook:", str(e))

        except Exception as e:
            # Call the logger function with a log level and message
            logger(logger_level_error, f"An error occurred while creating the dataframe from the input files {str(e)}.", execution_log_list, filename)
            print(*execution_log_list,sep='\n')
            raise Exception(f"An error occurred while creating the dataframe from the input files.", str(e))

except Exception as e:
    # Call the logger function with a log level and message
    logger(logger_level_error, f"Incorrect {source_table_path}, or no files are present in the given path {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"Incorrect {source_table_path}, or no files are present in the given path.", str(e))

# Check if the business_key is composite key
if ',' in business_key:
    business_key = business_key.split(',')
    # Call the logger function with a log level and message
    logger(logger_level_info, f"The business key has a composite key for the given table: {object_name}.", execution_log_list, filename)

# Check if the business_key value
if (business_key is None or (isinstance(business_key, str) and business_key.strip() == '') or (isinstance(business_key, list) and len(business_key) == 0)) and (dest_save_type == "SCD-2" or load_type == "INCREMENTAL"):
    # Call the logger function with a log level and message
    logger(logger_level_error, f"No primary key exists for the given table: {object_name}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"No primary key exists for the given table: {object_name}.")

try:
    # Define the pattern to match
    pattern = re.compile(r'pragati_(s1|s2|s3|s4|s5|s6|s7)')

    # Replace the pattern with the desired string
    object_source = pattern.sub('pragati', object_source)

    logger(logger_level_info, f"Fetching object_source is PRAGATI_S* changed it to pragati for table : {object_name}", execution_log_list, filename)

except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"Fetching object_source is PRAGATI_S* changed it to pragati for table : {object_name}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while changing object_source is PRAGATI_S* to pragati.", str(e))

# Checking if business key is empty or not.
if business_key is None or (isinstance(business_key, str) and business_key.strip() == '') or (isinstance(business_key, list) and not business_key):
    logger(logger_level_info, f"For the data quality framework, business_key {business_key} is empty or None; skip it.", execution_log_list, filename)
else:
    # Executing data quality framework
    try:
        # Call function to perform data quality checks
        source_data_df = data_quality_framework(synapse_jdbc_url, source_data_df, object_name, business_key, load_to_date, pipeline_run_id, object_source, src_object_id,column_to_exclude_frm_scd, adb_dq_dest_url)
        source_row_count = source_data_df.count()
        logger(logger_level_info, f"The DataFrame count after DQ for the table: {object_name} is {source_row_count}", execution_log_list, filename)
        logger(logger_level_info, f"Data quality framework has been successfully executed.", execution_log_list, filename)
    except Exception as e:
        logger(logger_level_error, f"An error occurred in the nb_dq_master notebook: {str(e)}", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        # Handle the exception or display the error message as needed
        raise Exception("An error occurred in the nb_dq_master notebook:", str(e))
    
# Check either object_name has _h at the end of string
if object_name.endswith("_h"):
    try:  
        # Remove "_h" or "_H" from the end of the string
        object_name = object_name[:-2]
        logger(logger_level_info, f"_h or _H has been removed from {object_name} and {desti_path} for historical pipeline execution.", execution_log_list, filename)
    except Exception as e:
        # Log the error along with the traceback
        logger(logger_level_error, f"There was an error while removing _h from {object_name} for historical pipeline execution.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"There was an error while removing _h from {object_name} for historical pipeline execution.", str(e))

try:
    # Construct the Delta table path
    delta_table_path = adb_curated_dest_url + "/" + desti_path
    
    # Check if the Delta table exists
    delta_table_exists = DeltaTable.isDeltaTable(spark, delta_table_path)
    
    if delta_table_exists and load_type != "ONE TIME LOAD":

        # Executing when load type equal to INCREMENTAL
        if load_type == "INCREMENTAL" or load_type == "TRANSACTIONAL"  or load_type == "FULL LOAD":

            if dest_save_type == "SCD-1":
                # Process for SCD Type 1
                try:
                    result = handle_scd_type_1(source_data_df, desti_path, object_name, business_key, updated_by, load_type, object_source, adb_curated_dest_url)
                except Exception as e:
                    logger(logger_level_error, f"An error occurred in the nb_scd_1_function notebook: {str(e)}", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    # Handle the exception or display the error message as needed
                    raise Exception("An error occurred in the nb_scd_1_function notebook:", str(e))

            if dest_save_type == "SCD-2":
                # Process for SCD Type 2
                try:
                    result = handle_scd_type_2(source_data_df, desti_path, object_name, business_key, updated_by, load_to_date, object_source, adb_curated_dest_url)
                except Exception as e:
                    logger(logger_level_error, f"An error occurred in the nb_scd_2_function notebook: {str(e)}", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    # Handle the exception or display the error message as needed
                    raise Exception("An error occurred in the nb_scd_2_function notebook:", str(e))    


            if result is not None :
                # counting total rows in dataframe
                source_row_count = source_data_df.count()

                try:
                    update_logs(src_object_id, source_data_df, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                except Exception as e:
                    logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    # Handle the exception or display the error message as needed
                    raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))

            else :
                # Call the logger function with a log level and message
                logger(logger_level_error, f"An error occurred while calling it; it should be either SCD type 1 or SCD type 2 for: {object_name}.", execution_log_list, filename)
                print(*execution_log_list,sep='\n')
                raise Exception(f"An error occurred while calling it; it should be either SCD type 1 or SCD type 2 for: {object_name}.")

    else :

        # Executing when load type is equal to ONE TIME LOAD 
        if load_type == "ONE TIME LOAD" or load_type == "FULL LOAD" :
            try :
                # Loading source data into existing table
                source_data_df.write.format("delta").mode("append").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
            
                logger(logger_level_info, f"The curated Delta table has been successfully loaded for the load type equal to ONE TIME LOAD, table: {object_name}.", execution_log_list, filename)
                source_row_count = source_data_df.count()

                try:
                    update_logs(src_object_id, source_data_df, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                except Exception as e:
                    logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    # Handle the exception or display the error message as needed
                    raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))

            except Exception as e:
                # Call the logger function with a log level and message
                logger(logger_level_error, f"An error occurred while appending to the Delta table path: {adb_curated_dest_url}{desti_path}.", execution_log_list, filename)
                print(*execution_log_list,sep='\n')
                raise Exception(f"An error occurred while appending to the Delta table path: {adb_curated_dest_url}{desti_path}.", str(e))

except Exception as e :
    # Call the logger function with a log level and message
    logger(logger_level_error, f"An error occurred. No condition has been satisfied for the load type {load_type}. If it is an INCREMENTAL table, it should be present : {object_name}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred. No condition has been satisfied for the load type {load_type}. If it is an INCREMENTAL table, it should be present : {object_name}", str(e))

# COMMAND ----------

################################################## End Of Program ################################################
