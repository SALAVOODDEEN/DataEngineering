# Databricks notebook source
# Declaring the notebook name
filename = 'nb_scd_implementation.dbc'

# COMMAND ----------

"""
    This function handles Slowly Changing Dimension (SCD) Type 1 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of the Snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""
    
def handle_scd_type_1(source_df, desti_path, object_name, primary_key, updated_by, load_type, object_source, adb_curated_dest_url):
    logger(logger_level_info, f"inside scd 1", execution_log_list, filename)
    try:
        # Construct the Delta table path
        delta_table_path = adb_curated_dest_url + "/" + desti_path
        
        # Check if the Delta table exists
        delta_table_exists = DeltaTable.isDeltaTable(spark, delta_table_path)

        # Checking load type
        if (load_type in ["INCREMENTAL", "FULL LOAD"]) and ((primary_key is not None and (isinstance(primary_key, str) and primary_key.strip() != '')) or (isinstance(primary_key, list) and len(primary_key) != 0)):

            logger(logger_level_info, f"inside 1st if condition, primary key is {primary_key}", execution_log_list, filename)
            
            if delta_table_exists:
                # If Delta table exists, merge the source data with the existing Delta table
                delta_table = DeltaTable.forPath(spark, delta_table_path)

                logger(logger_level_info, f"table exist for {delta_table_path}", execution_log_list, filename)

                # columns to avoid while updating records
                columns_to_exclude = ['ETL_CREATED_DATE']

                # Create a dictionary to map columns to be updated
                set_dict = {column: f"updates.{column}" for column in source_df.columns if column not in columns_to_exclude }

                # Check if primary_key is a single primary key or a list of primary keys
                if isinstance(primary_key, str):
                    join_condition = f"current.{primary_key} = updates.{primary_key}"
                elif isinstance(primary_key, (list, tuple)):
                    join_condition = " AND ".join([f"current.{key} = updates.{key}" for key in primary_key]) 

                logger(logger_level_info, f"join condition is {join_condition}", execution_log_list, filename)           

                delta_table.alias("current").merge(source_df.alias("updates"), join_condition) \
                    .whenMatchedUpdate(
                        condition= "current.ETL_HASH_COL != updates.ETL_HASH_COL",
                        set= {
                            **set_dict,
                            "ETL_CHANGE_FLAG" : lit("U"),
                            "ETL_LAST_UPDATED_BY" : lit(updated_by),
                            "ETL_LAST_UPDATED_DATE" : lit(datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')) ,
                            "ETL_HASH_COL": "updates.ETL_HASH_COL"
                            
                        }
                    ) \
                    .whenNotMatchedInsertAll().execute()

                logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully upserted: {object_name}.", execution_log_list, filename)
                return "success"
        
        # Checking load type
        if load_type == "FULL LOAD" and (primary_key is None or (isinstance(primary_key, str) and primary_key.strip() == '') or (isinstance(primary_key, list) and len(primary_key) == 0)):

            # For FULL LOAD load type truncate and load 
            max_retries = 10  # Maximum number of retries
            retry_delay = 50  # Delay between retries in seconds

            retry_count = 0
            success = False

            while retry_count < max_retries and not success:
                try:
                    dbutils.fs.rm(delta_table_path, recurse=True)
                    spark.sql(f"DROP TABLE {adb_curated_catlog_schema}.`{object_source}-{object_name}`")
     
                    logger(logger_level_info, f"truncated delta table path {delta_table_path} with table {object_name}", execution_log_list, filename)

                    # If Delta table is exist, overwrite Delta table and write the source data
                    source_df.write.format("delta").mode("append").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
                    logger(logger_level_info, f"overwrite delta table", execution_log_list, filename)
                    success = True
                except Exception as e:
                    retry_count += 1
                    logger(logger_level_error, f"An error occurred. Retrying in {retry_delay} seconds...", execution_log_list, filename)
                    time.sleep(retry_delay)

            if not success:
                logger(logger_level_error, f"Failed to execute the command after maximum retries is {max_retries}", execution_log_list, filename)

            logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully overwrite for load type {load_type} and for table {object_name}.", execution_log_list, filename)
            return "success"

        else :

            # If Delta table is exist appending source data
            source_df.write.format("delta").mode("append").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")

            logger(logger_level_info, f"In SCD Type 1, the curated delta table has been successfully appended for load type {load_type} and for table {object_name}.", execution_log_list, filename)
            return "success"
        
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"There is an error in the SCD Type 1 operation.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)

# COMMAND ----------

"""
    This function handles Slowly Changing Dimension (SCD) Type 2 operations.
    Args:
    source_df (DataFrame): The source incremental data.
    table_name (str): The name of full snapshot table.
    Returns:
    str: A message indicating whether the operation was successful.
"""

def handle_scd_type_2(source_df, desti_path, object_name, business_key, updated_by, load_to_date, object_source, adb_curated_dest_url):

    try:
        # Update timestamp minus 1 minutes from created timestamp
        current_timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')
        new_time = datetime.strptime(current_timestamp, '%Y-%m-%dT%H:%M:%SZ') - timedelta(minutes=1)
        update_timestamp = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Update effective_from_date minus 1 day of load_to_date
        new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
        load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Construct the Delta table path
        delta_table_path = adb_curated_dest_url + "/" + desti_path

        # Check if the Delta table exists
        delta_table_exists = DeltaTable.isDeltaTable(spark, delta_table_path)

        if delta_table_exists:
            # If Delta table exists, merge the source data with the existing Delta table
            delta_table = DeltaTable.forPath(spark, delta_table_path)

            load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"

            source_df = source_df.withColumn("ETL_IS_ACTIVE", lit("1"))\
                                .withColumn("ETL_EFFECTIVE_FROM_DATE", lit(load_to_date_for_new_data))\
                                .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

            # Check if business_key is a single primary key or a list of primary keys
            if isinstance(business_key, str):
                join_condition = f"existing.{business_key} = updates.{business_key}"
            elif isinstance(business_key, (list, tuple)):
                join_condition = " AND ".join([f"existing.{key} = updates.{key}" for key in business_key])

            # Update existing record
            delta_table.alias("existing").merge(
                source_df.alias("updates"),
                join_condition
            ).whenMatchedUpdate(
                condition="existing.ETL_HASH_COL != updates.ETL_HASH_COL and existing.ETL_IS_ACTIVE == 1",
                set={
                    "ETL_CHANGE_FLAG": lit("U"),
                    "ETL_LAST_UPDATED_BY": lit(updated_by),
                    "ETL_LAST_UPDATED_DATE": lit(update_timestamp),
                    "ETL_IS_ACTIVE": lit("0"),
                    "ETL_EFFECTIVE_TO_DATE": lit(load_to_date_minus_one_day)
                }
            ).whenNotMatchedInsertAll().execute()

            # Perform a left anti-join to filter out records from source_df present in delta_table
            source_df_filtered = source_df.alias("updates").join(
                delta_table.toDF().alias("existing"),
                (col("updates.ETL_HASH_COL") == col("existing.ETL_HASH_COL")) & (col("updates.ETL_IS_ACTIVE") == col("existing.ETL_IS_ACTIVE")),
                "left_anti"
            )

            # Insert new historical data only
            source_df_filtered.write.format("delta").mode("append").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.`{object_source}-{object_name}`")
            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully upserted for {object_name}.", execution_log_list, filename)
            return "success"

        else:

            # If Delta table does not exist, create a new Delta table and write the source data
            source_df.write.format("delta").mode("overwrite").option("path", delta_table_path).saveAsTable(f"{adb_curated_catlog_schema}.{object_name}")

            logger(logger_level_info, f"In SCD Type 2, the curated delta table has been successfully loaded for {object_name}.", execution_log_list, filename)
            return "success"

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"There was an error in the SCD Type 2 operation.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
