# Databricks notebook source
# Extra columns has been added into source data frame based on requirement.
def add_meta_data_into_source_df(source_data_df, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, object_name, load_to_date, load_type, desti_path) :
    
    # Declaring the notebook name
    filename = 'nb_add_meta_data_columns.dbc'

    try :
        # Defining current timestamp
        current_timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')

        # Defining current ETL User ID
        etl_user_id = spark.sql('select current_user() as user').collect()[0]['user']

        # Get all string columns excluding those specified
        string_columns = [col_name for col_name in source_data_df.columns if col_name not in column_to_exclude_frm_scd]

        # Apply crc32 function to concatenated string columns
        source_df = source_data_df.withColumn("ETL_HASH_COL", crc32(concat_ws("", *[col(col_name) for col_name in string_columns])))
        
        # Adding additional meta data columns and default values to the source data frame 
        source_data_df = source_df.withColumn("ETL_CHANGE_FLAG", lit("I"))\
                                        .withColumn("ETL_DQ_FINAL_STATUS", lit("1"))\
                                        .withColumn("ETL_DQ_ERROR", lit(None).cast("string"))\
                                        .withColumn("ETL_EXEC_LOG_ID", lit(exec_log_id).cast("string"))\
                                        .withColumn("ETL_CREATED_BY", lit(etl_user_id))\
                                        .withColumn("ETL_CREATED_DATE", lit(current_timestamp))\
                                        .withColumn("ETL_LAST_UPDATED_BY", lit(etl_user_id))\
                                        .withColumn("ETL_LAST_UPDATED_DATE", lit("9999-12-31T23:59:59Z"))\
                                        .withColumn("ETL_AUDIT_ID", lit(pipeline_run_id).cast("string"))
        
        if dest_save_type == "SCD-1" :
            source_data_df = source_data_df.withColumn("ETL_LAST_UPDATED_DATE", lit(current_timestamp))

            # Check if the object_name value has "_h" at the end
            if object_name.endswith("_h"):
          
                # Update effective_from_date minus 1 day of load_to_date
                new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
                load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

                source_data_df = source_data_df.withColumn("ETL_IS_ACTIVE",lit("0"))\
                    .withColumn("ETL_CHANGE_FLAG", lit("U"))\
                    .withColumn("ETL_LAST_UPDATED_DATE", lit(current_timestamp))\
                    .withColumn("ETL_EFFECTIVE_FROM_DATE", lit("1990-01-01T00:00:00Z"))\
                    .withColumn("ETL_EFFECTIVE_TO_DATE", lit(load_to_date_minus_one_day))

        if dest_save_type == "SCD-2" :

            # Check if the object_name value has "_h" at the end
            if object_name.endswith("_h"):
          
                # Update effective_from_date minus 1 day of load_to_date
                new_time = datetime.strptime(load_to_date, '%Y-%m-%dT%H:%M:%SZ') - timedelta(days=1)
                load_to_date_minus_one_day = new_time.strftime('%Y-%m-%dT%H:%M:%SZ')

                source_data_df = source_data_df.withColumn("ETL_IS_ACTIVE",lit("0"))\
                    .withColumn("ETL_CHANGE_FLAG", lit("U"))\
                    .withColumn("ETL_LAST_UPDATED_DATE", lit(current_timestamp))\
                    .withColumn("ETL_EFFECTIVE_FROM_DATE", lit("1990-01-01T00:00:00Z"))\
                    .withColumn("ETL_EFFECTIVE_TO_DATE", lit(load_to_date_minus_one_day))
                        
                try:
                    # Construct the Delta table path
                    delta_table_path = adb_curated_destination_url + desti_path
                    
                    # Check if the Delta table exists
                    delta_table_exists = DeltaTable.isDeltaTable(spark, delta_table_path)

                    load_to_date_for_new_data = load_to_date[:11] + "00:00:00Z"

                    if delta_table_exists and load_type == "ONE TIME LOAD":   
                        # Update effective_from_date as load_to_date
                        source_data_df = source_data_df.withColumn("ETL_IS_ACTIVE",lit("1"))\
                            .withColumn("ETL_EFFECTIVE_FROM_DATE", lit(load_to_date_for_new_data))\
                            .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

                except Exception as e :
                    # Call the logger function with a log level and message
                    logger(logger_level_error, f"An error occurred while checking if the table exists or not for the load type {load_type} with the '_h' condition. Please check: {object_name}.", execution_log_list, filename)
                    print(*execution_log_list,sep='\n')
                    raise Exception(f"An unexpected error occurred:", e)
            
            else :

                # Check if the object_name value has "_h" at the end
                if object_name.endswith("_h") is False:
                    # Update effective_from_date as 1990-01-01T00:00:00Z
                    source_data_df = source_data_df.withColumn("ETL_IS_ACTIVE",lit("1"))\
                        .withColumn("ETL_EFFECTIVE_FROM_DATE", lit("1990-01-01T00:00:00Z"))\
                        .withColumn("ETL_EFFECTIVE_TO_DATE", lit("9999-12-31T23:59:59Z"))

        return source_data_df
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"An error occurred while creating a DataFrame from input files with metadata columns.", execution_log_list, filename)
        print(*execution_log_list, sep='\n')
        raise Exception(f"An unexpected error occurred:", e)
