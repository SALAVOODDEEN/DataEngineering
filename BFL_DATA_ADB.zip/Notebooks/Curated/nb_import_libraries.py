# Databricks notebook source
# Importing required libraries
import operator
from pyspark.sql.functions import col, lit, when, count, date_format, concat_ws, collect_list, trim, split, lower, concat, length, array, date_diff, crc32, to_date, unix_timestamp, from_unixtime, upper, to_timestamp
from pyspark.sql.window import Window
import re, json
from datetime import datetime, timedelta
from pyspark.sql.types import StructType, StructField, StringType
import ast, inspect, pytz
from delta.tables import DeltaTable
from inspect import currentframe, getframeinfo
import time
from decimal import Decimal
