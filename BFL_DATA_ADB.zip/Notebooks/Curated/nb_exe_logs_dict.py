# Databricks notebook source
# Declaring the notebook name
filename = 'nb_exe_logs_dict.dbc'

# COMMAND ----------

try:
    def get_logs_dictionary(src_object_id, start_timestamp, end_timestamp, status, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, error_log) :
        # Define the schema for the DataFrame
        schema = StructType([
            StructField("exec_batch_id", StringType(), True),
            StructField("src_object_id", StringType(), True),
            StructField("layer_name", StringType(), True),
            StructField("start_datetime", StringType(), True),
            StructField("end_datetime", StringType(), True),
            StructField("task_duration", StringType(), True),
            StructField("status", StringType(), True),
            StructField("load_from_date", StringType(), True),  
            StructField("load_to_date", StringType(), True),
            StructField("load_from_id", StringType(), True),
            StructField("load_to_id", StringType(), True),
            StructField("pipeline_name", StringType(), True),
            StructField("pipeline_runid", StringType(), True),
            StructField("pipeline_trigger_name", StringType(), True),
            StructField("source_row_count", StringType(), True),
            StructField("destination_row_count", StringType(), True),
            StructField("error_log", StringType(), True),
            StructField("cons_tbl_name", StringType(), True)
        ])
 
        # Calculate the duration by subtracting end_time from start_time
        duration = end_timestamp - start_timestamp
 
        # Get the duration in seconds as an integer
        duration_seconds = int(duration.total_seconds())
   
        # Data formation for logger
        data = [
            ("",f"{src_object_id}","CURATED",f"{start_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')}",f"{end_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')}",f"{duration_seconds}",f"{status}",f"{load_from_date}", f"{load_to_date}","NA","NA",f"{pipeline_name}",f"{pipeline_run_id}",f"{pipeline_trigger_name}", f"{source_row_count}", f"{destination_row_count}", f"{error_log}","")
        ]
 
        # Create DataFrame
        pl_exec_log = spark.createDataFrame(data, schema)

        # Fetching adls storage account key from Azure Key vault by utilising secret scope
        logger(logger_level_info, f"The logs dictionary has been created successfully to pass it to ADF.", execution_log_list, filename)

        return [row.asDict() for row in pl_exec_log.collect()] 
 
except Exception as e:
    # Call the logger function with a log level and message
    logger(logger_level_error, f"Error while creating into append update log dictionary for ADF pipeline.", execution_log_list, filename)
    print(*execution_log_list, sep='\n')
    raise Exception(f"An unexpected error occurred:", e)
